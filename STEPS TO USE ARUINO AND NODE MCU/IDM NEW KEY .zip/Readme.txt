>>>>>> FTUApps.com <<<<<<

:: Instructions ::

0- Exit IDM from system tray
1- Install program overwrite to previous install if exists.
2- Exit IDM from system tray and task manager serives, close every serice related to IDM
3- Copy & replace file IDMan.exe from folder 'Crack' into the program folder means Copy and paste to installed directory (Overwrite)
4- Run RegKey.reg if you are using 32bit system and you're done!
5- Run RegKey_x64.reg if you are using windows 64bit, means use both one by one, and you're done!

NOTE: Remember, always Exclude the app via A/V program to avoid False positive infections, No harm by these infections, read more at torrent page description.

Visit https://ftuapps.com for more!